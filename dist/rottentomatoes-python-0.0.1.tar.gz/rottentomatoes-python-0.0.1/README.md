# Rotten Tomatoes Python

Basic usage:

```python
import rottentomatoes_python as rt
print(rt.tomatometer("happy gilmore"))

# Result: 61 (of type int)
```