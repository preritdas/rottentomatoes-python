class LookupError(Exception):
    pass

class URLCopyError(Exception):
    pass